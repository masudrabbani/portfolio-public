// Static test preview: no analytics requests, cookies, or measurement.
export function RegionalGoogleAnalytics(){return null}
export function GoogleAnalyticsControl(){return "Analytics is disabled on this test preview."}
export function browserPrivacySignalEnabled(){return true}
export function clearGoogleAnalyticsCookies(){}
export function disableGoogleAnalyticsInBrowser(){return true}
export function enableGoogleAnalyticsInBrowser(){return false}
export function prepareGoogleAnalyticsBrowserPreference(){return true}
